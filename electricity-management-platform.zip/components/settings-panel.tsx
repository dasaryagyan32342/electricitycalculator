'use client';

import { DollarSign, Globe } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { useEnergy } from '@/lib/energy-context';
import { CURRENCIES } from '@/lib/constants';

export function SettingsPanel() {
  const { settings, updateSettings, toggleDarkMode } = useEnergy();

  const handleCurrencyChange = (code: string) => {
    const currency = CURRENCIES.find((c) => c.code === code);
    if (currency) {
      updateSettings({ currency });
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold tracking-tight">Settings</h2>
        <p className="text-muted-foreground">
          Configure your electricity tariff and preferences
        </p>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        {/* Tariff Settings */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <DollarSign className="h-5 w-5 text-primary" />
              Electricity Tariff
            </CardTitle>
            <CardDescription>
              Set your electricity rate to calculate accurate costs
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="tariff">Cost per kWh</Label>
              <div className="relative">
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground">
                  {settings.currency.symbol}
                </span>
                <Input
                  id="tariff"
                  type="number"
                  step="0.01"
                  min="0"
                  value={settings.tariffRate}
                  onChange={(e) => updateSettings({ tariffRate: parseFloat(e.target.value) || 0 })}
                  className="pl-8"
                />
              </div>
              <p className="text-xs text-muted-foreground">
                Enter your electricity provider&apos;s rate per kilowatt-hour
              </p>
            </div>

            <div className="space-y-2">
              <Label htmlFor="currency">Currency</Label>
              <Select
                value={settings.currency.code}
                onValueChange={handleCurrencyChange}
              >
                <SelectTrigger id="currency">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {CURRENCIES.map((currency) => (
                    <SelectItem key={currency.code} value={currency.code}>
                      <span className="flex items-center gap-2">
                        <span className="font-mono">{currency.symbol}</span>
                        <span>{currency.name}</span>
                        <span className="text-muted-foreground">({currency.code})</span>
                      </span>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        {/* Display Settings */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Globe className="h-5 w-5 text-primary" />
              Display Preferences
            </CardTitle>
            <CardDescription>
              Customize your viewing experience
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between rounded-lg border border-border p-4">
              <div className="space-y-0.5">
                <Label htmlFor="dark-mode" className="text-base">Dark Mode</Label>
                <p className="text-sm text-muted-foreground">
                  Switch between light and dark themes
                </p>
              </div>
              <Switch
                id="dark-mode"
                checked={settings.darkMode}
                onCheckedChange={toggleDarkMode}
              />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Tariff Information */}
      <Card>
        <CardHeader>
          <CardTitle>Understanding Electricity Tariffs</CardTitle>
          <CardDescription>
            Tips for finding and using your electricity rate
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4 text-sm">
            <div className="rounded-lg bg-secondary/50 p-4">
              <h4 className="font-semibold mb-2">Where to find your tariff rate?</h4>
              <ul className="list-disc list-inside space-y-1 text-muted-foreground">
                <li>Check your electricity bill for the rate per kWh</li>
                <li>Visit your electricity provider&apos;s website</li>
                <li>Contact customer service for current rates</li>
                <li>Look for tiered rates if your usage varies</li>
              </ul>
            </div>
            <div className="rounded-lg bg-secondary/50 p-4">
              <h4 className="font-semibold mb-2">Average rates by region:</h4>
              <ul className="list-disc list-inside space-y-1 text-muted-foreground">
                <li>United States: $0.10 - $0.25 per kWh</li>
                <li>Europe: {'\u20AC'}0.15 - {'\u20AC'}0.35 per kWh</li>
                <li>United Kingdom: {'\u00A3'}0.20 - {'\u00A3'}0.35 per kWh</li>
                <li>India: {'\u20B9'}3 - {'\u20B9'}8 per kWh</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
