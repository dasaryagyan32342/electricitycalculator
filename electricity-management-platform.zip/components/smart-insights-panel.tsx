'use client';

import { useMemo } from 'react';
import {
  Zap,
  TrendingUp,
  TrendingDown,
  AlertTriangle,
  CheckCircle2,
  Clock,
  Gauge,
  Target,
  Award,
  Brain,
  Sparkles,
} from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { useEnergy } from '@/lib/energy-context';
import {
  calculateTotalEnergy,
  calculateApplianceEnergy,
  calculateEfficiencyScore,
  generateRecommendations,
} from '@/lib/calculations';
import { cn } from '@/lib/utils';

interface Insight {
  id: string;
  type: 'success' | 'warning' | 'info' | 'tip';
  title: string;
  description: string;
  icon: React.ComponentType<{ className?: string }>;
}

export function SmartInsightsPanel() {
  const { appliances, settings } = useEnergy();
  const calculations = calculateTotalEnergy(appliances, settings.tariffRate);
  const efficiencyScore = calculateEfficiencyScore(appliances);
  const recommendations = generateRecommendations(appliances, settings.tariffRate);

  const insights = useMemo((): Insight[] => {
    if (appliances.length === 0) return [];

    const insightsList: Insight[] = [];

    // Calculate appliance data
    const applianceData = appliances.map((appliance) => ({
      ...appliance,
      ...calculateApplianceEnergy(appliance),
    }));

    // Find top consumers
    const sortedByUsage = [...applianceData].sort((a, b) => b.monthlyKwh - a.monthlyKwh);
    const topConsumer = sortedByUsage[0];
    const topConsumerPercent = (topConsumer.monthlyKwh / calculations.monthlyKwh) * 100;

    if (topConsumerPercent > 40) {
      insightsList.push({
        id: 'top-consumer',
        type: 'warning',
        title: `${topConsumer.name} is your energy hog`,
        description: `This single appliance accounts for ${topConsumerPercent.toFixed(0)}% of your total consumption. Consider optimizing its usage or upgrading to a more efficient model.`,
        icon: AlertTriangle,
      });
    } else {
      insightsList.push({
        id: 'balanced-usage',
        type: 'success',
        title: 'Well-balanced energy distribution',
        description: `Your energy consumption is reasonably distributed across appliances. No single device dominates your usage.`,
        icon: CheckCircle2,
      });
    }

    // Check for high usage hours
    const highUsageAppliances = appliances.filter(
      (a) => a.dailyUsageHours > 8 && a.powerRating > 100
    );
    if (highUsageAppliances.length > 0) {
      insightsList.push({
        id: 'high-usage',
        type: 'warning',
        title: `${highUsageAppliances.length} appliance(s) running excessively`,
        description: `${highUsageAppliances.map((a) => a.name).join(', ')} ${highUsageAppliances.length > 1 ? 'are' : 'is'} running more than 8 hours daily. Review if this is necessary.`,
        icon: Clock,
      });
    }

    // Check for standby power wasters
    const alwaysOnDevices = appliances.filter((a) => a.dailyUsageHours >= 20);
    if (alwaysOnDevices.length > 3) {
      insightsList.push({
        id: 'standby-power',
        type: 'tip',
        title: 'Multiple always-on devices detected',
        description: `You have ${alwaysOnDevices.length} devices running nearly 24/7. Consider using smart power strips to reduce phantom power consumption.`,
        icon: Zap,
      });
    }

    // Efficiency score insight
    if (efficiencyScore >= 80) {
      insightsList.push({
        id: 'efficiency-high',
        type: 'success',
        title: 'Excellent energy efficiency',
        description: `Your efficiency score of ${efficiencyScore} indicates you're making smart choices. Keep up the good work!`,
        icon: Award,
      });
    } else if (efficiencyScore >= 50) {
      insightsList.push({
        id: 'efficiency-medium',
        type: 'info',
        title: 'Room for improvement',
        description: `Your efficiency score of ${efficiencyScore} shows moderate energy habits. Implementing a few changes could significantly improve this.`,
        icon: Target,
      });
    } else {
      insightsList.push({
        id: 'efficiency-low',
        type: 'warning',
        title: 'Energy efficiency needs attention',
        description: `Your efficiency score of ${efficiencyScore} suggests there's significant room for improvement. Check the recommendations for actionable tips.`,
        icon: AlertTriangle,
      });
    }

    // Predicted bill insight
    if (calculations.monthlyCost > 100) {
      insightsList.push({
        id: 'high-bill',
        type: 'tip',
        title: 'Predicted bill is on the higher side',
        description: `Your estimated monthly bill of ${settings.currency.symbol}${calculations.monthlyCost.toFixed(2)} could be reduced by following our recommendations.`,
        icon: TrendingDown,
      });
    }

    // Savings opportunity
    const totalSavings = recommendations.reduce((acc, r) => acc + r.potentialCostSavings, 0);
    if (totalSavings > 0) {
      insightsList.push({
        id: 'savings',
        type: 'success',
        title: `Potential savings: ${settings.currency.symbol}${totalSavings.toFixed(2)}/month`,
        description: `By implementing all ${recommendations.length} recommendations, you could save up to ${settings.currency.symbol}${(totalSavings * 12).toFixed(2)} annually.`,
        icon: TrendingUp,
      });
    }

    return insightsList;
  }, [appliances, calculations, efficiencyScore, recommendations, settings.currency.symbol]);

  const getScoreColor = (score: number) => {
    if (score >= 80) return 'text-green-600 dark:text-green-400';
    if (score >= 50) return 'text-amber-600 dark:text-amber-400';
    return 'text-red-600 dark:text-red-400';
  };

  const getScoreLabel = (score: number) => {
    if (score >= 80) return 'Excellent';
    if (score >= 60) return 'Good';
    if (score >= 40) return 'Fair';
    return 'Needs Improvement';
  };

  if (appliances.length === 0) {
    return (
      <div className="space-y-6">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">Dashboard</h2>
          <p className="text-muted-foreground">
            AI-powered insights and analysis of your energy usage
          </p>
        </div>
        <Card className="border-dashed">
          <CardContent className="flex flex-col items-center justify-center py-16">
            <div className="mb-4 rounded-full bg-primary/10 p-4">
              <Brain className="h-8 w-8 text-primary" />
            </div>
            <h3 className="mb-2 text-lg font-semibold">No Insights Available</h3>
            <p className="text-center text-muted-foreground">
              Add appliances to receive AI-powered insights about your energy usage
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold tracking-tight">Dashboard</h2>
        <p className="text-muted-foreground">
          AI-powered insights and personalized analysis
        </p>
      </div>

      {/* Efficiency Score Card */}
      <Card className="overflow-hidden">
        <div className="bg-gradient-to-r from-primary/10 via-primary/5 to-transparent">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Gauge className="h-5 w-5" />
              Energy Efficiency Score
            </CardTitle>
            <CardDescription>
              Overall assessment of your energy usage patterns
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col items-center gap-6 sm:flex-row sm:justify-between">
              <div className="relative flex h-40 w-40 items-center justify-center">
                <svg className="h-full w-full -rotate-90" viewBox="0 0 100 100">
                  <circle
                    cx="50"
                    cy="50"
                    r="45"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="8"
                    className="text-secondary"
                  />
                  <circle
                    cx="50"
                    cy="50"
                    r="45"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="8"
                    strokeDasharray={`${(efficiencyScore / 100) * 283} 283`}
                    strokeLinecap="round"
                    className={getScoreColor(efficiencyScore)}
                  />
                </svg>
                <div className="absolute flex flex-col items-center">
                  <span className={cn('text-4xl font-bold', getScoreColor(efficiencyScore))}>
                    {efficiencyScore}
                  </span>
                  <span className="text-xs text-muted-foreground">out of 100</span>
                </div>
              </div>
              <div className="flex-1 space-y-4">
                <div>
                  <p className={cn('text-2xl font-semibold', getScoreColor(efficiencyScore))}>
                    {getScoreLabel(efficiencyScore)}
                  </p>
                  <p className="text-sm text-muted-foreground">
                    Based on your appliance usage patterns and energy consumption
                  </p>
                </div>
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Score breakdown</span>
                    <span className="font-medium">{efficiencyScore}/100</span>
                  </div>
                  <Progress value={efficiencyScore} className="h-2" />
                </div>
              </div>
            </div>
          </CardContent>
        </div>
      </Card>

      {/* Quick Stats Row */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Monthly Energy</CardTitle>
            <Zap className="h-4 w-4 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{calculations.monthlyKwh.toFixed(1)} kWh</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Monthly Cost</CardTitle>
            <TrendingUp className="h-4 w-4 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {settings.currency.symbol}{calculations.monthlyCost.toFixed(2)}
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Appliances</CardTitle>
            <Sparkles className="h-4 w-4 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{appliances.length}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Recommendations</CardTitle>
            <Target className="h-4 w-4 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{recommendations.length}</div>
          </CardContent>
        </Card>
      </div>

      {/* Smart Insights */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Brain className="h-5 w-5 text-primary" />
            Smart Insights
          </CardTitle>
          <CardDescription>
            AI-powered analysis of your energy usage patterns
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {insights.map((insight) => {
              const Icon = insight.icon;
              const styles = {
                success: {
                  bg: 'bg-green-50 dark:bg-green-900/20',
                  border: 'border-green-200 dark:border-green-800',
                  iconColor: 'text-green-600 dark:text-green-400',
                },
                warning: {
                  bg: 'bg-amber-50 dark:bg-amber-900/20',
                  border: 'border-amber-200 dark:border-amber-800',
                  iconColor: 'text-amber-600 dark:text-amber-400',
                },
                info: {
                  bg: 'bg-blue-50 dark:bg-blue-900/20',
                  border: 'border-blue-200 dark:border-blue-800',
                  iconColor: 'text-blue-600 dark:text-blue-400',
                },
                tip: {
                  bg: 'bg-primary/5',
                  border: 'border-primary/20',
                  iconColor: 'text-primary',
                },
              };

              const style = styles[insight.type];

              return (
                <div
                  key={insight.id}
                  className={cn(
                    'flex gap-4 rounded-lg border p-4',
                    style.bg,
                    style.border
                  )}
                >
                  <div className={cn('shrink-0', style.iconColor)}>
                    <Icon className="h-5 w-5" />
                  </div>
                  <div>
                    <h4 className="font-semibold">{insight.title}</h4>
                    <p className="text-sm text-muted-foreground">{insight.description}</p>
                  </div>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>

      {/* Predicted Bills */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <TrendingUp className="h-5 w-5 text-primary" />
            Bill Predictions
          </CardTitle>
          <CardDescription>
            Estimated future electricity bills based on current usage
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 sm:grid-cols-4">
            {[
              { label: 'This Month', value: calculations.monthlyCost },
              { label: 'Next Month', value: calculations.monthlyCost * 1.02 },
              { label: '3 Months', value: calculations.monthlyCost * 3.05 },
              { label: 'Next Year', value: calculations.yearlyCost * 1.05 },
            ].map((prediction, index) => (
              <div
                key={index}
                className="rounded-lg bg-secondary/50 p-4 text-center"
              >
                <p className="text-sm text-muted-foreground">{prediction.label}</p>
                <p className="text-2xl font-bold text-primary">
                  {settings.currency.symbol}{prediction.value.toFixed(2)}
                </p>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
