'use client';

import { Zap, DollarSign, TrendingUp, Calendar, Calculator as CalculatorIcon, Info } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { useEnergy } from '@/lib/energy-context';
import { calculateTotalEnergy, calculateApplianceEnergy, formatKwh, formatCurrency } from '@/lib/calculations';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Progress } from '@/components/ui/progress';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";

export function EnergyCalculator() {
  const { appliances, settings } = useEnergy();
  const calculations = calculateTotalEnergy(appliances, settings.tariffRate);

  const applianceBreakdown = appliances.map((appliance) => {
    const energy = calculateApplianceEnergy(appliance);
    return {
      ...appliance,
      ...energy,
      monthlyCost: energy.monthlyKwh * settings.tariffRate,
      percentOfTotal: calculations.monthlyKwh > 0 
        ? (energy.monthlyKwh / calculations.monthlyKwh) * 100 
        : 0,
    };
  }).sort((a, b) => b.monthlyKwh - a.monthlyKwh);

  const topConsumer = applianceBreakdown[0];

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold tracking-tight">Energy Calculator</h2>
        <p className="text-muted-foreground">
          Real-time energy consumption and cost calculations
        </p>
      </div>

      {appliances.length === 0 ? (
        <Card className="border-dashed">
          <CardContent className="flex flex-col items-center justify-center py-16">
            <div className="mb-4 rounded-full bg-primary/10 p-4">
              <CalculatorIcon className="h-8 w-8 text-primary" />
            </div>
            <h3 className="mb-2 text-lg font-semibold">No Data to Calculate</h3>
            <p className="text-center text-muted-foreground">
              Add appliances to see your energy consumption calculations
            </p>
          </CardContent>
        </Card>
      ) : (
        <>
          {/* Summary Cards */}
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Daily Consumption</CardTitle>
                <Zap className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-primary">
                  {formatKwh(calculations.dailyKwh)}
                </div>
                <p className="text-xs text-muted-foreground">
                  {formatCurrency(calculations.dailyCost, settings.currency.symbol)} per day
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Monthly Consumption</CardTitle>
                <Calendar className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-primary">
                  {formatKwh(calculations.monthlyKwh)}
                </div>
                <p className="text-xs text-muted-foreground">
                  {formatCurrency(calculations.monthlyCost, settings.currency.symbol)} per month
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Annual Consumption</CardTitle>
                <TrendingUp className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-primary">
                  {formatKwh(calculations.yearlyKwh)}
                </div>
                <p className="text-xs text-muted-foreground">
                  {formatCurrency(calculations.yearlyCost, settings.currency.symbol)} per year
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Estimated Monthly Bill</CardTitle>
                <DollarSign className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-primary">
                  {formatCurrency(calculations.monthlyCost, settings.currency.symbol)}
                </div>
                <p className="text-xs text-muted-foreground">
                  At {formatCurrency(settings.tariffRate, settings.currency.symbol)}/kWh
                </p>
              </CardContent>
            </Card>
          </div>

          {/* Top Consumer Card */}
          {topConsumer && (
            <Card className="bg-primary/5 border-primary/20">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-lg">
                  <TrendingUp className="h-5 w-5 text-primary" />
                  Top Energy Consumer
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
                  <div>
                    <p className="text-2xl font-bold">{topConsumer.name}</p>
                    <p className="text-muted-foreground">
                      {topConsumer.percentOfTotal.toFixed(1)}% of total consumption
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="text-xl font-semibold text-primary">
                      {formatKwh(topConsumer.monthlyKwh)}/month
                    </p>
                    <p className="text-muted-foreground">
                      {formatCurrency(topConsumer.monthlyCost, settings.currency.symbol)}/month
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Detailed Breakdown Table */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                Appliance-wise Breakdown
                <TooltipProvider>
                  <Tooltip>
                    <TooltipTrigger>
                      <Info className="h-4 w-4 text-muted-foreground" />
                    </TooltipTrigger>
                    <TooltipContent>
                      <p>Detailed energy consumption for each appliance</p>
                    </TooltipContent>
                  </Tooltip>
                </TooltipProvider>
              </CardTitle>
              <CardDescription>
                See how each appliance contributes to your energy usage
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Appliance</TableHead>
                      <TableHead className="text-right">Power</TableHead>
                      <TableHead className="text-right">Daily</TableHead>
                      <TableHead className="text-right">Monthly</TableHead>
                      <TableHead className="text-right">Cost</TableHead>
                      <TableHead className="w-32">Share</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {applianceBreakdown.map((item) => (
                      <TableRow key={item.id}>
                        <TableCell className="font-medium">
                          {item.name}
                          {item.quantity > 1 && (
                            <span className="ml-1 text-muted-foreground">
                              x{item.quantity}
                            </span>
                          )}
                        </TableCell>
                        <TableCell className="text-right">{item.powerRating}W</TableCell>
                        <TableCell className="text-right">{item.dailyKwh.toFixed(2)} kWh</TableCell>
                        <TableCell className="text-right">{item.monthlyKwh.toFixed(2)} kWh</TableCell>
                        <TableCell className="text-right">
                          {formatCurrency(item.monthlyCost, settings.currency.symbol)}
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <Progress value={item.percentOfTotal} className="h-2" />
                            <span className="w-10 text-xs text-muted-foreground">
                              {item.percentOfTotal.toFixed(0)}%
                            </span>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>

          {/* Cost Projection */}
          <Card>
            <CardHeader>
              <CardTitle>Cost Projections</CardTitle>
              <CardDescription>
                Estimated electricity costs based on current usage
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid gap-6 sm:grid-cols-3">
                <div className="text-center rounded-lg bg-secondary/50 p-6">
                  <p className="text-sm text-muted-foreground mb-2">This Month</p>
                  <p className="text-3xl font-bold text-primary">
                    {formatCurrency(calculations.monthlyCost, settings.currency.symbol)}
                  </p>
                </div>
                <div className="text-center rounded-lg bg-secondary/50 p-6">
                  <p className="text-sm text-muted-foreground mb-2">This Quarter</p>
                  <p className="text-3xl font-bold text-primary">
                    {formatCurrency(calculations.monthlyCost * 3, settings.currency.symbol)}
                  </p>
                </div>
                <div className="text-center rounded-lg bg-secondary/50 p-6">
                  <p className="text-sm text-muted-foreground mb-2">This Year</p>
                  <p className="text-3xl font-bold text-primary">
                    {formatCurrency(calculations.yearlyCost, settings.currency.symbol)}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </>
      )}
    </div>
  );
}
