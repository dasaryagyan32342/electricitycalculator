'use client';

import { useMemo } from 'react';
import { Leaf, TreePine, Car, Factory, Globe, TrendingDown, Info } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { useEnergy } from '@/lib/energy-context';
import { calculateTotalEnergy, calculateCarbonFootprint } from '@/lib/calculations';

export function CarbonFootprintPanel() {
  const { appliances, settings } = useEnergy();
  const calculations = calculateTotalEnergy(appliances, settings.tariffRate);
  
  const carbonData = useMemo(() => {
    return calculateCarbonFootprint(calculations.monthlyKwh);
  }, [calculations.monthlyKwh]);

  // Average household emissions for comparison (kg CO2/year)
  const avgHouseholdEmissions = 4000;
  const userYearlyPercentOfAvg = (carbonData.yearlyCO2Kg / avgHouseholdEmissions) * 100;

  if (appliances.length === 0) {
    return (
      <div className="space-y-6">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">Carbon Footprint</h2>
          <p className="text-muted-foreground">
            Track your environmental impact from electricity usage
          </p>
        </div>
        <Card className="border-dashed">
          <CardContent className="flex flex-col items-center justify-center py-16">
            <div className="mb-4 rounded-full bg-primary/10 p-4">
              <Leaf className="h-8 w-8 text-primary" />
            </div>
            <h3 className="mb-2 text-lg font-semibold">No Data Available</h3>
            <p className="text-center text-muted-foreground">
              Add appliances to calculate your carbon footprint
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold tracking-tight">Carbon Footprint</h2>
        <p className="text-muted-foreground">
          Understand your environmental impact from electricity consumption
        </p>
      </div>

      {/* Main Stats */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Monthly CO2</CardTitle>
            <Factory className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-primary">
              {carbonData.monthlyCO2Kg.toFixed(1)} kg
            </div>
            <p className="text-xs text-muted-foreground">
              Carbon dioxide emissions
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Yearly CO2</CardTitle>
            <Globe className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-primary">
              {carbonData.yearlyCO2Kg.toFixed(0)} kg
            </div>
            <p className="text-xs text-muted-foreground">
              Projected annual emissions
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Trees to Offset</CardTitle>
            <TreePine className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600 dark:text-green-400">
              {carbonData.treesNeeded}
            </div>
            <p className="text-xs text-muted-foreground">
              Trees needed per year
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Vehicle Equivalent</CardTitle>
            <Car className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-amber-600 dark:text-amber-400">
              {carbonData.vehicleKmEquivalent.toLocaleString()} km
            </div>
            <p className="text-xs text-muted-foreground">
              Driving distance equivalent
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Comparison with Average */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            Comparison with Average Household
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger>
                  <Info className="h-4 w-4 text-muted-foreground" />
                </TooltipTrigger>
                <TooltipContent>
                  <p>Based on average household electricity emissions</p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
          </CardTitle>
          <CardDescription>
            How your emissions compare to typical household usage
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span>Your yearly emissions</span>
              <span className="font-medium">{carbonData.yearlyCO2Kg.toFixed(0)} kg CO2</span>
            </div>
            <Progress 
              value={Math.min(userYearlyPercentOfAvg, 100)} 
              className="h-3"
            />
            <div className="flex justify-between text-xs text-muted-foreground">
              <span>0 kg</span>
              <span>Average: {avgHouseholdEmissions.toLocaleString()} kg</span>
            </div>
          </div>

          <div className="rounded-lg bg-secondary/50 p-4">
            <p className="text-sm">
              {userYearlyPercentOfAvg < 50 ? (
                <span className="text-green-600 dark:text-green-400 font-medium">
                  Excellent! Your emissions are {(100 - userYearlyPercentOfAvg).toFixed(0)}% below the average household.
                </span>
              ) : userYearlyPercentOfAvg < 100 ? (
                <span className="text-amber-600 dark:text-amber-400 font-medium">
                  Good! Your emissions are {(100 - userYearlyPercentOfAvg).toFixed(0)}% below the average household.
                </span>
              ) : (
                <span className="text-red-600 dark:text-red-400 font-medium">
                  Your emissions are {(userYearlyPercentOfAvg - 100).toFixed(0)}% above the average household. Consider implementing energy-saving measures.
                </span>
              )}
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Environmental Impact Details */}
      <div className="grid gap-6 lg:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TreePine className="h-5 w-5 text-green-600" />
              Tree Offset Details
            </CardTitle>
            <CardDescription>
              What it takes to neutralize your emissions
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between rounded-lg bg-green-50 dark:bg-green-900/20 p-4">
              <div className="flex items-center gap-3">
                <div className="flex h-12 w-12 items-center justify-center rounded-full bg-green-100 dark:bg-green-900/50">
                  <TreePine className="h-6 w-6 text-green-600 dark:text-green-400" />
                </div>
                <div>
                  <p className="font-semibold">Trees Required</p>
                  <p className="text-sm text-muted-foreground">To offset yearly emissions</p>
                </div>
              </div>
              <div className="text-3xl font-bold text-green-600 dark:text-green-400">
                {carbonData.treesNeeded}
              </div>
            </div>
            
            <div className="space-y-2 text-sm text-muted-foreground">
              <p>
                An average tree absorbs approximately <span className="font-medium text-foreground">21 kg of CO2</span> per year.
              </p>
              <p>
                Your yearly emissions of <span className="font-medium text-foreground">{carbonData.yearlyCO2Kg.toFixed(0)} kg CO2</span> would require planting and maintaining {carbonData.treesNeeded} trees for one year.
              </p>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Car className="h-5 w-5 text-amber-600" />
              Vehicle Emissions Comparison
            </CardTitle>
            <CardDescription>
              Your electricity usage in driving terms
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between rounded-lg bg-amber-50 dark:bg-amber-900/20 p-4">
              <div className="flex items-center gap-3">
                <div className="flex h-12 w-12 items-center justify-center rounded-full bg-amber-100 dark:bg-amber-900/50">
                  <Car className="h-6 w-6 text-amber-600 dark:text-amber-400" />
                </div>
                <div>
                  <p className="font-semibold">Driving Equivalent</p>
                  <p className="text-sm text-muted-foreground">In annual kilometers</p>
                </div>
              </div>
              <div className="text-3xl font-bold text-amber-600 dark:text-amber-400">
                {carbonData.vehicleKmEquivalent.toLocaleString()}
              </div>
            </div>
            
            <div className="space-y-2 text-sm text-muted-foreground">
              <p>
                An average car emits approximately <span className="font-medium text-foreground">0.21 kg CO2</span> per kilometer.
              </p>
              <p>
                Your electricity usage produces the same emissions as driving a car for <span className="font-medium text-foreground">{carbonData.vehicleKmEquivalent.toLocaleString()} km</span> annually.
              </p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Tips for Reducing Carbon Footprint */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <TrendingDown className="h-5 w-5 text-primary" />
            Ways to Reduce Your Carbon Footprint
          </CardTitle>
          <CardDescription>
            Simple changes that can make a big difference
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {[
              {
                title: 'Switch to LED',
                desc: 'LED bulbs use 75% less energy than incandescent',
                impact: 'High Impact',
              },
              {
                title: 'Renewable Energy',
                desc: 'Consider solar panels or green energy providers',
                impact: 'High Impact',
              },
              {
                title: 'Energy Star Appliances',
                desc: 'Replace old appliances with efficient models',
                impact: 'High Impact',
              },
              {
                title: 'Smart Thermostat',
                desc: 'Optimize heating and cooling automatically',
                impact: 'Medium Impact',
              },
              {
                title: 'Unplug Devices',
                desc: 'Eliminate phantom power from standby devices',
                impact: 'Medium Impact',
              },
              {
                title: 'Air Dry Laundry',
                desc: 'Skip the dryer when possible',
                impact: 'Medium Impact',
              },
            ].map((tip, index) => (
              <div
                key={index}
                className="rounded-lg border border-border p-4 transition-colors hover:bg-secondary/50"
              >
                <h4 className="font-semibold">{tip.title}</h4>
                <p className="text-sm text-muted-foreground mt-1">{tip.desc}</p>
                <span className="inline-block mt-2 text-xs font-medium text-primary">
                  {tip.impact}
                </span>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
