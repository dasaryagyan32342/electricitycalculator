'use client';

import { useMemo } from 'react';
import { BarChart3, PieChart as PieChartIcon, TrendingUp, Zap, DollarSign } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { useEnergy } from '@/lib/energy-context';
import { calculateApplianceEnergy, calculateTotalEnergy } from '@/lib/calculations';
import {
  PieChart,
  Pie,
  Cell,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  LineChart,
  Line,
  Area,
  AreaChart,
} from 'recharts';

const CHART_COLORS = [
  'hsl(155, 60%, 45%)',
  'hsl(200, 60%, 50%)',
  'hsl(85, 60%, 50%)',
  'hsl(180, 50%, 45%)',
  'hsl(220, 60%, 55%)',
  'hsl(45, 70%, 55%)',
  'hsl(280, 50%, 55%)',
  'hsl(340, 55%, 50%)',
  'hsl(25, 65%, 50%)',
  'hsl(120, 45%, 45%)',
];

export function AnalyticsDashboard() {
  const { appliances, settings } = useEnergy();
  const calculations = calculateTotalEnergy(appliances, settings.tariffRate);

  const pieData = useMemo(() => {
    return appliances.map((appliance) => {
      const energy = calculateApplianceEnergy(appliance);
      return {
        name: appliance.name,
        value: parseFloat(energy.monthlyKwh.toFixed(2)),
        cost: energy.monthlyKwh * settings.tariffRate,
      };
    }).sort((a, b) => b.value - a.value);
  }, [appliances, settings.tariffRate]);

  const barData = useMemo(() => {
    const categoryMap = new Map<string, { energy: number; cost: number }>();
    
    appliances.forEach((appliance) => {
      const category = appliance.category || 'Other';
      const energy = calculateApplianceEnergy(appliance);
      const existing = categoryMap.get(category) || { energy: 0, cost: 0 };
      categoryMap.set(category, {
        energy: existing.energy + energy.monthlyKwh,
        cost: existing.cost + energy.monthlyKwh * settings.tariffRate,
      });
    });

    return Array.from(categoryMap.entries())
      .map(([name, data]) => ({
        name,
        energy: parseFloat(data.energy.toFixed(2)),
        cost: parseFloat(data.cost.toFixed(2)),
      }))
      .sort((a, b) => b.energy - a.energy);
  }, [appliances, settings.tariffRate]);

  const monthlyTrend = useMemo(() => {
    const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    const baseUsage = calculations.monthlyKwh;
    
    // Simulate seasonal variation (higher in summer/winter)
    const seasonalFactors = [1.15, 1.1, 1.0, 0.9, 0.85, 0.95, 1.1, 1.15, 1.0, 0.9, 0.95, 1.1];
    
    return months.map((month, index) => ({
      month,
      energy: parseFloat((baseUsage * seasonalFactors[index]).toFixed(2)),
      cost: parseFloat((baseUsage * seasonalFactors[index] * settings.tariffRate).toFixed(2)),
    }));
  }, [calculations.monthlyKwh, settings.tariffRate]);

  const savingsComparison = useMemo(() => {
    const optimizedUsage = calculations.monthlyKwh * 0.8; // Assume 20% savings potential
    return [
      {
        name: 'Current',
        energy: parseFloat(calculations.monthlyKwh.toFixed(2)),
        cost: parseFloat(calculations.monthlyCost.toFixed(2)),
      },
      {
        name: 'Optimized',
        energy: parseFloat(optimizedUsage.toFixed(2)),
        cost: parseFloat((optimizedUsage * settings.tariffRate).toFixed(2)),
      },
    ];
  }, [calculations, settings.tariffRate]);

  if (appliances.length === 0) {
    return (
      <div className="space-y-6">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">Analytics Dashboard</h2>
          <p className="text-muted-foreground">
            Visualize your energy consumption patterns
          </p>
        </div>
        <Card className="border-dashed">
          <CardContent className="flex flex-col items-center justify-center py-16">
            <div className="mb-4 rounded-full bg-primary/10 p-4">
              <BarChart3 className="h-8 w-8 text-primary" />
            </div>
            <h3 className="mb-2 text-lg font-semibold">No Data to Display</h3>
            <p className="text-center text-muted-foreground">
              Add appliances to see analytics and visualizations
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold tracking-tight">Analytics Dashboard</h2>
        <p className="text-muted-foreground">
          Interactive charts and insights about your energy usage
        </p>
      </div>

      {/* Quick Stats */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Appliances</CardTitle>
            <Zap className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{appliances.length}</div>
            <p className="text-xs text-muted-foreground">
              Across {new Set(appliances.map(a => a.category)).size} categories
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Avg Daily Cost</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {settings.currency.symbol}{calculations.dailyCost.toFixed(2)}
            </div>
            <p className="text-xs text-muted-foreground">
              {calculations.dailyKwh.toFixed(2)} kWh/day
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Highest Consumer</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold truncate">{pieData[0]?.name || 'N/A'}</div>
            <p className="text-xs text-muted-foreground">
              {pieData[0]?.value.toFixed(2)} kWh/month
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Savings Potential</CardTitle>
            <PieChartIcon className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">
              {settings.currency.symbol}{(calculations.monthlyCost * 0.2).toFixed(2)}
            </div>
            <p className="text-xs text-muted-foreground">
              ~20% potential monthly savings
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Charts Grid */}
      <div className="grid gap-6 lg:grid-cols-2">
        {/* Energy by Appliance Pie Chart */}
        <Card>
          <CardHeader>
            <CardTitle>Energy by Appliance</CardTitle>
            <CardDescription>Monthly consumption distribution</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={pieData}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                    outerRadius={100}
                    fill="#8884d8"
                    dataKey="value"
                  >
                    {pieData.map((entry, index) => (
                      <Cell 
                        key={`cell-${index}`} 
                        fill={CHART_COLORS[index % CHART_COLORS.length]} 
                      />
                    ))}
                  </Pie>
                  <Tooltip
                    formatter={(value: number) => [`${value} kWh`, 'Energy']}
                    contentStyle={{
                      backgroundColor: 'hsl(var(--card))',
                      borderColor: 'hsl(var(--border))',
                      borderRadius: '8px',
                    }}
                  />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        {/* Category Bar Chart */}
        <Card>
          <CardHeader>
            <CardTitle>Energy by Category</CardTitle>
            <CardDescription>Consumption grouped by appliance type</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={barData} layout="vertical">
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                  <XAxis type="number" stroke="hsl(var(--muted-foreground))" fontSize={12} />
                  <YAxis 
                    dataKey="name" 
                    type="category" 
                    width={100}
                    stroke="hsl(var(--muted-foreground))"
                    fontSize={12}
                  />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: 'hsl(var(--card))',
                      borderColor: 'hsl(var(--border))',
                      borderRadius: '8px',
                    }}
                    formatter={(value: number, name: string) => [
                      name === 'energy' ? `${value} kWh` : `${settings.currency.symbol}${value}`,
                      name === 'energy' ? 'Energy' : 'Cost'
                    ]}
                  />
                  <Bar 
                    dataKey="energy" 
                    fill="hsl(155, 60%, 45%)" 
                    radius={[0, 4, 4, 0]}
                    name="Energy (kWh)"
                  />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        {/* Monthly Trend Line Chart */}
        <Card>
          <CardHeader>
            <CardTitle>Monthly Usage Trend</CardTitle>
            <CardDescription>Projected energy consumption throughout the year</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={monthlyTrend}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                  <XAxis 
                    dataKey="month" 
                    stroke="hsl(var(--muted-foreground))"
                    fontSize={12}
                  />
                  <YAxis 
                    stroke="hsl(var(--muted-foreground))"
                    fontSize={12}
                  />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: 'hsl(var(--card))',
                      borderColor: 'hsl(var(--border))',
                      borderRadius: '8px',
                    }}
                    formatter={(value: number, name: string) => [
                      name === 'energy' ? `${value} kWh` : `${settings.currency.symbol}${value}`,
                      name === 'energy' ? 'Energy' : 'Cost'
                    ]}
                  />
                  <Legend />
                  <Area
                    type="monotone"
                    dataKey="energy"
                    stroke="hsl(155, 60%, 45%)"
                    fill="hsl(155, 60%, 45%)"
                    fillOpacity={0.3}
                    name="Energy (kWh)"
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        {/* Savings Comparison */}
        <Card>
          <CardHeader>
            <CardTitle>Current vs Optimized Usage</CardTitle>
            <CardDescription>Potential savings with energy optimization</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={savingsComparison}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                  <XAxis 
                    dataKey="name" 
                    stroke="hsl(var(--muted-foreground))"
                    fontSize={12}
                  />
                  <YAxis 
                    stroke="hsl(var(--muted-foreground))"
                    fontSize={12}
                  />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: 'hsl(var(--card))',
                      borderColor: 'hsl(var(--border))',
                      borderRadius: '8px',
                    }}
                  />
                  <Legend />
                  <Bar 
                    dataKey="energy" 
                    fill="hsl(200, 60%, 50%)" 
                    radius={[4, 4, 0, 0]}
                    name="Energy (kWh)"
                  />
                  <Bar 
                    dataKey="cost" 
                    fill="hsl(155, 60%, 45%)" 
                    radius={[4, 4, 0, 0]}
                    name={`Cost (${settings.currency.symbol})`}
                  />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Cost Distribution */}
      <Card>
        <CardHeader>
          <CardTitle>Cost Distribution</CardTitle>
          <CardDescription>Monthly cost breakdown by appliance</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={pieData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={100}
                  fill="#8884d8"
                  paddingAngle={2}
                  dataKey="cost"
                  label={({ name, value }) => `${name}: ${settings.currency.symbol}${value.toFixed(2)}`}
                >
                  {pieData.map((entry, index) => (
                    <Cell 
                      key={`cell-${index}`} 
                      fill={CHART_COLORS[index % CHART_COLORS.length]} 
                    />
                  ))}
                </Pie>
                <Tooltip
                  formatter={(value: number) => [`${settings.currency.symbol}${value.toFixed(2)}`, 'Cost']}
                  contentStyle={{
                    backgroundColor: 'hsl(var(--card))',
                    borderColor: 'hsl(var(--border))',
                    borderRadius: '8px',
                  }}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
