'use client';

import { useState } from 'react';
import {
  Plus,
  Trash2,
  Edit2,
  X,
  Snowflake,
  Tv,
  Laptop,
  Monitor,
  Flame,
  Fan,
  Lightbulb,
  Wifi,
  Smartphone,
  Gamepad2,
  Wind,
  Coffee,
  Sandwich,
  Utensils,
  Shirt,
  Zap,
  Search,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { useEnergy } from '@/lib/energy-context';
import { APPLIANCE_PRESETS, CATEGORIES } from '@/lib/constants';
import { Appliance, AppliancePreset } from '@/lib/types';
import { calculateApplianceEnergy, formatKwh } from '@/lib/calculations';
import { cn } from '@/lib/utils';

const iconMap: Record<string, React.ComponentType<{ className?: string }>> = {
  Snowflake,
  Refrigerator: Snowflake,
  WashingMachine: Fan,
  Tv,
  Laptop,
  Monitor,
  Microwave: Coffee,
  Flame,
  Fan,
  Lightbulb,
  Shirt,
  Wind,
  Coffee,
  Sandwich,
  Utensils,
  Oven: Flame,
  Heater: Flame,
  Wifi,
  Smartphone,
  Gamepad2,
};

function getIcon(iconName: string) {
  return iconMap[iconName] || Zap;
}

export function ApplianceManager() {
  const { appliances, addAppliance, updateAppliance, removeAppliance, clearAllAppliances, settings } = useEnergy();
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingAppliance, setEditingAppliance] = useState<Appliance | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  
  const [formData, setFormData] = useState({
    name: '',
    quantity: 1,
    powerRating: 0,
    dailyUsageHours: 1,
    daysPerMonth: 30,
    category: 'Other',
    icon: 'Zap',
  });

  const filteredAppliances = appliances.filter((appliance) => {
    const matchesSearch = appliance.name.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === 'all' || appliance.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const handlePresetSelect = (preset: AppliancePreset) => {
    setFormData({
      name: preset.name,
      quantity: 1,
      powerRating: preset.powerRating,
      dailyUsageHours: preset.typicalUsage,
      daysPerMonth: 30,
      category: preset.category,
      icon: preset.icon,
    });
  };

  const handleSubmit = () => {
    if (!formData.name || formData.powerRating <= 0) return;
    
    if (editingAppliance) {
      updateAppliance(editingAppliance.id, formData);
    } else {
      addAppliance(formData);
    }
    
    resetForm();
    setIsDialogOpen(false);
  };

  const handleEdit = (appliance: Appliance) => {
    setEditingAppliance(appliance);
    setFormData({
      name: appliance.name,
      quantity: appliance.quantity,
      powerRating: appliance.powerRating,
      dailyUsageHours: appliance.dailyUsageHours,
      daysPerMonth: appliance.daysPerMonth,
      category: appliance.category || 'Other',
      icon: appliance.icon || 'Zap',
    });
    setIsDialogOpen(true);
  };

  const resetForm = () => {
    setFormData({
      name: '',
      quantity: 1,
      powerRating: 0,
      dailyUsageHours: 1,
      daysPerMonth: 30,
      category: 'Other',
      icon: 'Zap',
    });
    setEditingAppliance(null);
  };

  const usedCategories = [...new Set(appliances.map(a => a.category).filter(Boolean))];

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">Appliances</h2>
          <p className="text-muted-foreground">
            Manage your household appliances and their usage
          </p>
        </div>
        <div className="flex gap-2">
          {appliances.length > 0 && (
            <Button variant="outline" onClick={clearAllAppliances}>
              <Trash2 className="mr-2 h-4 w-4" />
              Clear All
            </Button>
          )}
          <Button onClick={() => setIsDialogOpen(true)}>
            <Plus className="mr-2 h-4 w-4" />
            Add Appliance
          </Button>
        </div>
      </div>

      {/* Search and Filter */}
      {appliances.length > 0 && (
        <div className="flex flex-col gap-4 sm:flex-row">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              placeholder="Search appliances..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-9"
            />
          </div>
          <Select value={selectedCategory} onValueChange={setSelectedCategory}>
            <SelectTrigger className="w-full sm:w-48">
              <SelectValue placeholder="All Categories" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Categories</SelectItem>
              {usedCategories.map((cat) => (
                <SelectItem key={cat} value={cat || 'Other'}>
                  {cat}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      )}

      {/* Appliance List */}
      {appliances.length === 0 ? (
        <Card className="border-dashed">
          <CardContent className="flex flex-col items-center justify-center py-16">
            <div className="mb-4 rounded-full bg-primary/10 p-4">
              <Zap className="h-8 w-8 text-primary" />
            </div>
            <h3 className="mb-2 text-lg font-semibold">No Appliances Added</h3>
            <p className="mb-4 text-center text-muted-foreground">
              Start by adding your household appliances to calculate energy consumption
            </p>
            <Button onClick={() => setIsDialogOpen(true)}>
              <Plus className="mr-2 h-4 w-4" />
              Add Your First Appliance
            </Button>
          </CardContent>
        </Card>
      ) : filteredAppliances.length === 0 ? (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-12">
            <Search className="mb-4 h-8 w-8 text-muted-foreground" />
            <p className="text-muted-foreground">No appliances match your search</p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {filteredAppliances.map((appliance) => {
            const Icon = getIcon(appliance.icon || 'Zap');
            const energy = calculateApplianceEnergy(appliance);
            const monthlyCost = energy.monthlyKwh * settings.tariffRate;
            
            return (
              <Card key={appliance.id} className="group relative overflow-hidden transition-shadow hover:shadow-md">
                <div className="absolute right-2 top-2 flex gap-1 opacity-0 transition-opacity group-hover:opacity-100">
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-8 w-8"
                    onClick={() => handleEdit(appliance)}
                  >
                    <Edit2 className="h-4 w-4" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-8 w-8 text-destructive hover:text-destructive"
                    onClick={() => removeAppliance(appliance.id)}
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
                <CardHeader className="pb-2">
                  <div className="flex items-center gap-3">
                    <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
                      <Icon className="h-5 w-5 text-primary" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <CardTitle className="truncate text-base">
                        {appliance.name}
                        {appliance.quantity > 1 && (
                          <span className="ml-1 text-muted-foreground">
                            x{appliance.quantity}
                          </span>
                        )}
                      </CardTitle>
                      <CardDescription className="text-xs">
                        {appliance.category || 'Other'}
                      </CardDescription>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 gap-3 text-sm">
                    <div>
                      <p className="text-muted-foreground">Power</p>
                      <p className="font-medium">{appliance.powerRating}W</p>
                    </div>
                    <div>
                      <p className="text-muted-foreground">Usage</p>
                      <p className="font-medium">{appliance.dailyUsageHours}h/day</p>
                    </div>
                    <div>
                      <p className="text-muted-foreground">Monthly</p>
                      <p className="font-medium text-primary">{formatKwh(energy.monthlyKwh)}</p>
                    </div>
                    <div>
                      <p className="text-muted-foreground">Cost</p>
                      <p className="font-medium text-primary">
                        {settings.currency.symbol}{monthlyCost.toFixed(2)}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}

      {/* Add/Edit Dialog */}
      <Dialog open={isDialogOpen} onOpenChange={(open) => {
        if (!open) resetForm();
        setIsDialogOpen(open);
      }}>
        <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>
              {editingAppliance ? 'Edit Appliance' : 'Add New Appliance'}
            </DialogTitle>
            <DialogDescription>
              {editingAppliance
                ? 'Update the details of your appliance'
                : 'Add a new appliance or choose from presets'}
            </DialogDescription>
          </DialogHeader>

          {!editingAppliance && (
            <div className="space-y-3">
              <Label className="text-sm font-medium">Quick Select Presets</Label>
              <div className="grid max-h-40 grid-cols-2 gap-2 overflow-y-auto rounded-lg border border-border p-2 sm:grid-cols-3">
                {APPLIANCE_PRESETS.map((preset) => {
                  const Icon = getIcon(preset.icon);
                  return (
                    <button
                      key={preset.name}
                      type="button"
                      className={cn(
                        'flex items-center gap-2 rounded-md border border-transparent p-2 text-left text-sm transition-colors hover:bg-secondary',
                        formData.name === preset.name && 'border-primary bg-primary/10'
                      )}
                      onClick={() => handlePresetSelect(preset)}
                    >
                      <Icon className="h-4 w-4 shrink-0 text-primary" />
                      <span className="truncate">{preset.name}</span>
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          <div className="grid gap-4">
            <div className="grid gap-2">
              <Label htmlFor="name">Appliance Name</Label>
              <Input
                id="name"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                placeholder="e.g., Air Conditioner"
              />
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div className="grid gap-2">
                <Label htmlFor="quantity">Quantity</Label>
                <Input
                  id="quantity"
                  type="number"
                  min={1}
                  value={formData.quantity}
                  onChange={(e) => setFormData({ ...formData, quantity: parseInt(e.target.value) || 1 })}
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="power">Power Rating (W)</Label>
                <Input
                  id="power"
                  type="number"
                  min={1}
                  value={formData.powerRating || ''}
                  onChange={(e) => setFormData({ ...formData, powerRating: parseFloat(e.target.value) || 0 })}
                  placeholder="e.g., 1500"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="grid gap-2">
                <Label htmlFor="usage">Daily Usage (hours)</Label>
                <Input
                  id="usage"
                  type="number"
                  min={0.1}
                  max={24}
                  step={0.5}
                  value={formData.dailyUsageHours}
                  onChange={(e) => setFormData({ ...formData, dailyUsageHours: parseFloat(e.target.value) || 1 })}
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="days">Days per Month</Label>
                <Input
                  id="days"
                  type="number"
                  min={1}
                  max={31}
                  value={formData.daysPerMonth}
                  onChange={(e) => setFormData({ ...formData, daysPerMonth: parseInt(e.target.value) || 30 })}
                />
              </div>
            </div>

            <div className="grid gap-2">
              <Label htmlFor="category">Category</Label>
              <Select
                value={formData.category}
                onValueChange={(value) => setFormData({ ...formData, category: value })}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select category" />
                </SelectTrigger>
                <SelectContent>
                  {CATEGORIES.map((cat) => (
                    <SelectItem key={cat} value={cat}>
                      {cat}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <DialogFooter className="gap-2 sm:gap-0">
            <Button variant="outline" onClick={() => {
              resetForm();
              setIsDialogOpen(false);
            }}>
              Cancel
            </Button>
            <Button 
              onClick={handleSubmit}
              disabled={!formData.name || formData.powerRating <= 0}
            >
              {editingAppliance ? 'Save Changes' : 'Add Appliance'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
