'use client';

import { useState } from 'react';
import { Download, FileText, Loader2, Check } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { useEnergy } from '@/lib/energy-context';
import {
  calculateTotalEnergy,
  calculateApplianceEnergy,
  calculateCarbonFootprint,
  calculateEfficiencyScore,
  generateRecommendations,
} from '@/lib/calculations';

export function ExportPanel() {
  const { appliances, settings } = useEnergy();
  const [isExporting, setIsExporting] = useState(false);
  const [exportSuccess, setExportSuccess] = useState(false);

  const calculations = calculateTotalEnergy(appliances, settings.tariffRate);
  const carbonData = calculateCarbonFootprint(calculations.monthlyKwh);
  const efficiencyScore = calculateEfficiencyScore(appliances);
  const recommendations = generateRecommendations(appliances, settings.tariffRate);

  const handleExportPDF = async () => {
    if (appliances.length === 0) return;
    
    setIsExporting(true);
    setExportSuccess(false);

    try {
      const { jsPDF } = await import('jspdf');
      const doc = new jsPDF();

      // Colors
      const primaryColor: [number, number, number] = [34, 139, 34];
      const textColor: [number, number, number] = [51, 51, 51];
      const lightGray: [number, number, number] = [240, 240, 240];

      let yPos = 20;

      // Header
      doc.setFillColor(...primaryColor);
      doc.rect(0, 0, 210, 40, 'F');
      doc.setTextColor(255, 255, 255);
      doc.setFontSize(24);
      doc.setFont('helvetica', 'bold');
      doc.text('EcoWatt Energy Report', 105, 25, { align: 'center' });
      doc.setFontSize(10);
      doc.setFont('helvetica', 'normal');
      doc.text(`Generated on ${new Date().toLocaleDateString()}`, 105, 35, { align: 'center' });

      yPos = 55;
      doc.setTextColor(...textColor);

      // Summary Section
      doc.setFontSize(16);
      doc.setFont('helvetica', 'bold');
      doc.text('Energy Summary', 20, yPos);
      yPos += 10;

      doc.setFillColor(...lightGray);
      doc.rect(20, yPos - 5, 170, 45, 'F');

      doc.setFontSize(11);
      doc.setFont('helvetica', 'normal');

      const summaryData = [
        ['Monthly Consumption:', `${calculations.monthlyKwh.toFixed(2)} kWh`],
        ['Annual Consumption:', `${calculations.yearlyKwh.toFixed(2)} kWh`],
        ['Monthly Cost:', `${settings.currency.symbol}${calculations.monthlyCost.toFixed(2)}`],
        ['Annual Cost:', `${settings.currency.symbol}${calculations.yearlyCost.toFixed(2)}`],
        ['Efficiency Score:', `${efficiencyScore}/100`],
      ];

      summaryData.forEach(([label, value], index) => {
        doc.setFont('helvetica', 'bold');
        doc.text(label, 25, yPos + (index * 8));
        doc.setFont('helvetica', 'normal');
        doc.text(value, 100, yPos + (index * 8));
      });

      yPos += 55;

      // Appliances Section
      doc.setFontSize(16);
      doc.setFont('helvetica', 'bold');
      doc.text('Appliance Breakdown', 20, yPos);
      yPos += 10;

      // Table header
      doc.setFillColor(...primaryColor);
      doc.rect(20, yPos - 5, 170, 8, 'F');
      doc.setTextColor(255, 255, 255);
      doc.setFontSize(9);
      doc.setFont('helvetica', 'bold');
      doc.text('Appliance', 25, yPos);
      doc.text('Power (W)', 75, yPos);
      doc.text('Daily Hours', 105, yPos);
      doc.text('Monthly kWh', 140, yPos);
      doc.text('Cost', 175, yPos);
      yPos += 8;

      doc.setTextColor(...textColor);
      doc.setFont('helvetica', 'normal');

      appliances.forEach((appliance, index) => {
        if (yPos > 270) {
          doc.addPage();
          yPos = 20;
        }

        const energy = calculateApplianceEnergy(appliance);
        const cost = energy.monthlyKwh * settings.tariffRate;

        if (index % 2 === 0) {
          doc.setFillColor(250, 250, 250);
          doc.rect(20, yPos - 4, 170, 7, 'F');
        }

        doc.text(appliance.name.substring(0, 18), 25, yPos);
        doc.text(appliance.powerRating.toString(), 80, yPos);
        doc.text(appliance.dailyUsageHours.toString(), 115, yPos);
        doc.text(energy.monthlyKwh.toFixed(2), 145, yPos);
        doc.text(`${settings.currency.symbol}${cost.toFixed(2)}`, 175, yPos);
        yPos += 7;
      });

      yPos += 10;

      // Carbon Footprint Section
      if (yPos > 230) {
        doc.addPage();
        yPos = 20;
      }

      doc.setFontSize(16);
      doc.setFont('helvetica', 'bold');
      doc.text('Carbon Footprint', 20, yPos);
      yPos += 10;

      doc.setFillColor(...lightGray);
      doc.rect(20, yPos - 5, 170, 30, 'F');

      doc.setFontSize(11);
      doc.setFont('helvetica', 'normal');

      const carbonInfo = [
        ['Monthly CO2 Emissions:', `${carbonData.monthlyCO2Kg.toFixed(2)} kg`],
        ['Annual CO2 Emissions:', `${carbonData.yearlyCO2Kg.toFixed(2)} kg`],
        ['Trees Needed to Offset:', `${carbonData.treesNeeded} trees/year`],
      ];

      carbonInfo.forEach(([label, value], index) => {
        doc.setFont('helvetica', 'bold');
        doc.text(label, 25, yPos + (index * 8));
        doc.setFont('helvetica', 'normal');
        doc.text(value, 100, yPos + (index * 8));
      });

      yPos += 40;

      // Recommendations Section
      if (yPos > 200) {
        doc.addPage();
        yPos = 20;
      }

      doc.setFontSize(16);
      doc.setFont('helvetica', 'bold');
      doc.text('Recommendations', 20, yPos);
      yPos += 10;

      doc.setFontSize(10);
      recommendations.slice(0, 5).forEach((rec, index) => {
        if (yPos > 270) {
          doc.addPage();
          yPos = 20;
        }

        doc.setFont('helvetica', 'bold');
        doc.text(`${index + 1}. ${rec.title}`, 25, yPos);
        yPos += 5;
        doc.setFont('helvetica', 'normal');
        
        const lines = doc.splitTextToSize(rec.description, 160);
        lines.forEach((line: string) => {
          doc.text(line, 30, yPos);
          yPos += 5;
        });
        
        doc.setTextColor(...primaryColor);
        doc.text(`Potential savings: ${settings.currency.symbol}${rec.potentialCostSavings.toFixed(2)}/month`, 30, yPos);
        doc.setTextColor(...textColor);
        yPos += 10;
      });

      // Footer
      const pageCount = doc.internal.pages.length - 1;
      for (let i = 1; i <= pageCount; i++) {
        doc.setPage(i);
        doc.setFontSize(8);
        doc.setTextColor(128, 128, 128);
        doc.text(
          `Page ${i} of ${pageCount} | Generated by EcoWatt Energy Saver`,
          105,
          290,
          { align: 'center' }
        );
      }

      doc.save('ecowatt-energy-report.pdf');
      setExportSuccess(true);
      setTimeout(() => setExportSuccess(false), 3000);
    } catch (error) {
      console.error('Error generating PDF:', error);
    } finally {
      setIsExporting(false);
    }
  };

  const handleExportCSV = () => {
    if (appliances.length === 0) return;

    const headers = ['Appliance', 'Quantity', 'Power (W)', 'Daily Hours', 'Days/Month', 'Monthly kWh', 'Monthly Cost'];
    const rows = appliances.map((appliance) => {
      const energy = calculateApplianceEnergy(appliance);
      const cost = energy.monthlyKwh * settings.tariffRate;
      return [
        appliance.name,
        appliance.quantity,
        appliance.powerRating,
        appliance.dailyUsageHours,
        appliance.daysPerMonth,
        energy.monthlyKwh.toFixed(2),
        cost.toFixed(2),
      ];
    });

    // Add summary row
    rows.push([]);
    rows.push(['SUMMARY']);
    rows.push(['Total Monthly kWh', '', '', '', '', calculations.monthlyKwh.toFixed(2)]);
    rows.push(['Total Monthly Cost', '', '', '', '', '', `${settings.currency.symbol}${calculations.monthlyCost.toFixed(2)}`]);
    rows.push(['Efficiency Score', '', '', '', '', '', `${efficiencyScore}/100`]);

    const csvContent = [headers, ...rows]
      .map((row) => row.map((cell) => `"${cell}"`).join(','))
      .join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = 'ecowatt-energy-data.csv';
    link.click();
  };

  const handleExportJSON = () => {
    if (appliances.length === 0) return;

    const data = {
      exportDate: new Date().toISOString(),
      settings: {
        tariffRate: settings.tariffRate,
        currency: settings.currency,
      },
      appliances: appliances.map((appliance) => {
        const energy = calculateApplianceEnergy(appliance);
        return {
          ...appliance,
          calculatedEnergy: energy,
          monthlyCost: energy.monthlyKwh * settings.tariffRate,
        };
      }),
      summary: {
        totalMonthlyKwh: calculations.monthlyKwh,
        totalYearlyKwh: calculations.yearlyKwh,
        totalMonthlyCost: calculations.monthlyCost,
        totalYearlyCost: calculations.yearlyCost,
        efficiencyScore,
      },
      carbonFootprint: carbonData,
      recommendations: recommendations.slice(0, 10),
    };

    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = 'ecowatt-energy-data.json';
    link.click();
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold tracking-tight">Export Report</h2>
        <p className="text-muted-foreground">
          Download your energy usage data in various formats
        </p>
      </div>

      {appliances.length === 0 ? (
        <Card className="border-dashed">
          <CardContent className="flex flex-col items-center justify-center py-16">
            <div className="mb-4 rounded-full bg-primary/10 p-4">
              <Download className="h-8 w-8 text-primary" />
            </div>
            <h3 className="mb-2 text-lg font-semibold">No Data to Export</h3>
            <p className="text-center text-muted-foreground">
              Add appliances to generate and export reports
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-6 md:grid-cols-3">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5 text-red-600" />
                PDF Report
              </CardTitle>
              <CardDescription>
                Comprehensive formatted report with charts and recommendations
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Button
                onClick={handleExportPDF}
                disabled={isExporting}
                className="w-full"
              >
                {isExporting ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Generating...
                  </>
                ) : exportSuccess ? (
                  <>
                    <Check className="mr-2 h-4 w-4" />
                    Downloaded!
                  </>
                ) : (
                  <>
                    <Download className="mr-2 h-4 w-4" />
                    Download PDF
                  </>
                )}
              </Button>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5 text-green-600" />
                CSV Spreadsheet
              </CardTitle>
              <CardDescription>
                Tabular data for use in Excel or Google Sheets
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Button
                onClick={handleExportCSV}
                variant="outline"
                className="w-full"
              >
                <Download className="mr-2 h-4 w-4" />
                Download CSV
              </Button>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5 text-blue-600" />
                JSON Data
              </CardTitle>
              <CardDescription>
                Raw data format for developers and integrations
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Button
                onClick={handleExportJSON}
                variant="outline"
                className="w-full"
              >
                <Download className="mr-2 h-4 w-4" />
                Download JSON
              </Button>
            </CardContent>
          </Card>
        </div>
      )}

      {appliances.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Report Preview</CardTitle>
            <CardDescription>
              Summary of data included in your export
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
              <div className="rounded-lg bg-secondary/50 p-4">
                <p className="text-sm text-muted-foreground">Appliances</p>
                <p className="text-2xl font-bold">{appliances.length}</p>
              </div>
              <div className="rounded-lg bg-secondary/50 p-4">
                <p className="text-sm text-muted-foreground">Monthly Energy</p>
                <p className="text-2xl font-bold">{calculations.monthlyKwh.toFixed(1)} kWh</p>
              </div>
              <div className="rounded-lg bg-secondary/50 p-4">
                <p className="text-sm text-muted-foreground">Monthly Cost</p>
                <p className="text-2xl font-bold">
                  {settings.currency.symbol}{calculations.monthlyCost.toFixed(2)}
                </p>
              </div>
              <div className="rounded-lg bg-secondary/50 p-4">
                <p className="text-sm text-muted-foreground">Recommendations</p>
                <p className="text-2xl font-bold">{recommendations.length}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
