'use client';

import { useMemo } from 'react';
import {
  Lightbulb,
  TrendingDown,
  DollarSign,
  Zap,
  Thermometer,
  Refrigerator,
  Tv,
  Monitor,
  Flame,
  Plug,
  Clock,
  Home,
  AlertTriangle,
  CheckCircle2,
} from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { useEnergy } from '@/lib/energy-context';
import { generateRecommendations, calculateTotalEnergy } from '@/lib/calculations';
import { cn } from '@/lib/utils';

const iconMap: Record<string, React.ComponentType<{ className?: string }>> = {
  Thermometer,
  Refrigerator,
  Lightbulb,
  Monitor,
  Flame,
  Tv,
  Plug,
  Clock,
  Home,
};

function getIcon(iconName: string) {
  return iconMap[iconName] || Lightbulb;
}

const priorityConfig = {
  high: {
    color: 'text-red-600 dark:text-red-400',
    bgColor: 'bg-red-100 dark:bg-red-900/30',
    badgeVariant: 'destructive' as const,
    label: 'High Priority',
  },
  medium: {
    color: 'text-amber-600 dark:text-amber-400',
    bgColor: 'bg-amber-100 dark:bg-amber-900/30',
    badgeVariant: 'secondary' as const,
    label: 'Medium Priority',
  },
  low: {
    color: 'text-green-600 dark:text-green-400',
    bgColor: 'bg-green-100 dark:bg-green-900/30',
    badgeVariant: 'outline' as const,
    label: 'Low Priority',
  },
};

export function RecommendationsPanel() {
  const { appliances, settings } = useEnergy();
  const calculations = calculateTotalEnergy(appliances, settings.tariffRate);
  
  const recommendations = useMemo(() => {
    return generateRecommendations(appliances, settings.tariffRate);
  }, [appliances, settings.tariffRate]);

  const totalPotentialSavings = recommendations.reduce(
    (acc, rec) => ({
      kwh: acc.kwh + rec.potentialSavingsKwh,
      cost: acc.cost + rec.potentialCostSavings,
    }),
    { kwh: 0, cost: 0 }
  );

  if (appliances.length === 0) {
    return (
      <div className="space-y-6">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">Recommendations</h2>
          <p className="text-muted-foreground">
            Personalized energy-saving tips and suggestions
          </p>
        </div>
        <Card className="border-dashed">
          <CardContent className="flex flex-col items-center justify-center py-16">
            <div className="mb-4 rounded-full bg-primary/10 p-4">
              <Lightbulb className="h-8 w-8 text-primary" />
            </div>
            <h3 className="mb-2 text-lg font-semibold">No Recommendations Yet</h3>
            <p className="text-center text-muted-foreground">
              Add appliances to receive personalized energy-saving recommendations
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold tracking-tight">Recommendations</h2>
        <p className="text-muted-foreground">
          Personalized tips to reduce your energy consumption
        </p>
      </div>

      {/* Summary Cards */}
      <div className="grid gap-4 sm:grid-cols-3">
        <Card className="bg-primary/5 border-primary/20">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium flex items-center gap-2">
              <Lightbulb className="h-4 w-4" />
              Total Recommendations
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-primary">
              {recommendations.length}
            </div>
            <p className="text-xs text-muted-foreground">
              Based on your appliance usage
            </p>
          </CardContent>
        </Card>

        <Card className="bg-green-50 dark:bg-green-900/20 border-green-200 dark:border-green-800">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium flex items-center gap-2">
              <Zap className="h-4 w-4" />
              Potential Energy Savings
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-green-600 dark:text-green-400">
              {totalPotentialSavings.kwh.toFixed(1)} kWh
            </div>
            <p className="text-xs text-muted-foreground">
              Per month if all implemented
            </p>
          </CardContent>
        </Card>

        <Card className="bg-blue-50 dark:bg-blue-900/20 border-blue-200 dark:border-blue-800">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium flex items-center gap-2">
              <DollarSign className="h-4 w-4" />
              Potential Cost Savings
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-blue-600 dark:text-blue-400">
              {settings.currency.symbol}{totalPotentialSavings.cost.toFixed(2)}
            </div>
            <p className="text-xs text-muted-foreground">
              Per month if all implemented
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Recommendations List */}
      <div className="space-y-4">
        {recommendations.map((rec) => {
          const Icon = getIcon(rec.icon);
          const priority = priorityConfig[rec.priority];

          return (
            <Card key={rec.id} className="overflow-hidden">
              <div className={cn('h-1', {
                'bg-red-500': rec.priority === 'high',
                'bg-amber-500': rec.priority === 'medium',
                'bg-green-500': rec.priority === 'low',
              })} />
              <CardContent className="pt-4">
                <div className="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
                  <div className="flex gap-4">
                    <div className={cn('flex h-12 w-12 shrink-0 items-center justify-center rounded-lg', priority.bgColor)}>
                      <Icon className={cn('h-6 w-6', priority.color)} />
                    </div>
                    <div className="space-y-1">
                      <div className="flex items-center gap-2 flex-wrap">
                        <h3 className="font-semibold">{rec.title}</h3>
                        <Badge variant={priority.badgeVariant} className="text-xs">
                          {priority.label}
                        </Badge>
                      </div>
                      <p className="text-sm text-muted-foreground">
                        {rec.description}
                      </p>
                      {rec.appliance && (
                        <p className="text-xs text-muted-foreground">
                          Applies to: <span className="font-medium text-foreground">{rec.appliance}</span>
                        </p>
                      )}
                    </div>
                  </div>
                  <div className="flex flex-row gap-4 sm:flex-col sm:text-right">
                    <div>
                      <p className="text-xs text-muted-foreground">Save up to</p>
                      <p className="font-semibold text-green-600 dark:text-green-400">
                        {settings.currency.symbol}{rec.potentialCostSavings.toFixed(2)}/mo
                      </p>
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground">Energy reduction</p>
                      <p className="font-semibold text-primary">
                        {rec.potentialSavingsPercent}%
                      </p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Quick Tips Section */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <CheckCircle2 className="h-5 w-5 text-primary" />
            Quick Energy Saving Tips
          </CardTitle>
          <CardDescription>
            General best practices for reducing electricity consumption
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 sm:grid-cols-2">
            {[
              'Unplug devices when not in use to eliminate standby power',
              'Use natural light during the day instead of artificial lighting',
              'Wash clothes in cold water when possible',
              'Clean or replace HVAC filters regularly',
              'Use ceiling fans to reduce AC dependency',
              'Enable power-saving modes on all devices',
              'Air dry dishes instead of using dishwasher heat dry',
              'Seal air leaks around windows and doors',
            ].map((tip, index) => (
              <div key={index} className="flex items-start gap-2 text-sm">
                <CheckCircle2 className="h-4 w-4 shrink-0 mt-0.5 text-primary" />
                <span className="text-muted-foreground">{tip}</span>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
