'use client';

import { useState } from 'react';
import { EnergyProvider } from '@/lib/energy-context';
import { Header } from '@/components/header';
import { Sidebar } from '@/components/sidebar';
import { SmartInsightsPanel } from '@/components/smart-insights-panel';
import { ApplianceManager } from '@/components/appliance-manager';
import { EnergyCalculator } from '@/components/energy-calculator';
import { AnalyticsDashboard } from '@/components/analytics-dashboard';
import { RecommendationsPanel } from '@/components/recommendations-panel';
import { CarbonFootprintPanel } from '@/components/carbon-footprint-panel';
import { SettingsPanel } from '@/components/settings-panel';
import { ExportPanel } from '@/components/export-panel';

function MainContent() {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);

  const renderContent = () => {
    switch (activeTab) {
      case 'dashboard':
        return <SmartInsightsPanel />;
      case 'appliances':
        return <ApplianceManager />;
      case 'calculator':
        return <EnergyCalculator />;
      case 'analytics':
        return <AnalyticsDashboard />;
      case 'recommendations':
        return <RecommendationsPanel />;
      case 'carbon':
        return <CarbonFootprintPanel />;
      case 'settings':
        return <SettingsPanel />;
      case 'export':
        return <ExportPanel />;
      default:
        return <SmartInsightsPanel />;
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Header
        onMenuClick={() => setIsSidebarOpen(!isSidebarOpen)}
        isSidebarOpen={isSidebarOpen}
      />
      <Sidebar
        activeTab={activeTab}
        onTabChange={setActiveTab}
        isOpen={isSidebarOpen}
        onClose={() => setIsSidebarOpen(false)}
      />
      <main className="lg:pl-64">
        <div className="container mx-auto p-4 lg:p-6">
          {renderContent()}
        </div>
      </main>
    </div>
  );
}

export default function Home() {
  return (
    <EnergyProvider>
      <MainContent />
    </EnergyProvider>
  );
}
