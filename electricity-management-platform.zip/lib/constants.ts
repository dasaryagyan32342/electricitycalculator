import { AppliancePreset, Currency } from './types';

export const APPLIANCE_PRESETS: AppliancePreset[] = [
  { name: 'Air Conditioner', powerRating: 1500, icon: 'Snowflake', category: 'Cooling', typicalUsage: 8 },
  { name: 'Refrigerator', powerRating: 150, icon: 'Refrigerator', category: 'Kitchen', typicalUsage: 24 },
  { name: 'Washing Machine', powerRating: 500, icon: 'WashingMachine', category: 'Laundry', typicalUsage: 1 },
  { name: 'Television', powerRating: 100, icon: 'Tv', category: 'Entertainment', typicalUsage: 5 },
  { name: 'Laptop', powerRating: 65, icon: 'Laptop', category: 'Computing', typicalUsage: 8 },
  { name: 'Desktop Computer', powerRating: 300, icon: 'Monitor', category: 'Computing', typicalUsage: 8 },
  { name: 'Microwave', powerRating: 1000, icon: 'Microwave', category: 'Kitchen', typicalUsage: 0.5 },
  { name: 'Water Heater', powerRating: 3000, icon: 'Flame', category: 'Heating', typicalUsage: 3 },
  { name: 'Ceiling Fan', powerRating: 75, icon: 'Fan', category: 'Cooling', typicalUsage: 10 },
  { name: 'LED Bulb', powerRating: 10, icon: 'Lightbulb', category: 'Lighting', typicalUsage: 6 },
  { name: 'Electric Iron', powerRating: 1000, icon: 'Shirt', category: 'Laundry', typicalUsage: 0.5 },
  { name: 'Hair Dryer', powerRating: 1500, icon: 'Wind', category: 'Personal', typicalUsage: 0.25 },
  { name: 'Electric Kettle', powerRating: 1500, icon: 'Coffee', category: 'Kitchen', typicalUsage: 0.5 },
  { name: 'Toaster', powerRating: 800, icon: 'Sandwich', category: 'Kitchen', typicalUsage: 0.25 },
  { name: 'Dishwasher', powerRating: 1800, icon: 'Utensils', category: 'Kitchen', typicalUsage: 1 },
  { name: 'Electric Oven', powerRating: 2000, icon: 'Oven', category: 'Kitchen', typicalUsage: 1 },
  { name: 'Room Heater', powerRating: 2000, icon: 'Heater', category: 'Heating', typicalUsage: 6 },
  { name: 'WiFi Router', powerRating: 10, icon: 'Wifi', category: 'Electronics', typicalUsage: 24 },
  { name: 'Phone Charger', powerRating: 20, icon: 'Smartphone', category: 'Electronics', typicalUsage: 3 },
  { name: 'Gaming Console', powerRating: 150, icon: 'Gamepad2', category: 'Entertainment', typicalUsage: 4 },
];

export const CURRENCIES: Currency[] = [
  { code: 'USD', symbol: '$', name: 'US Dollar' },
  { code: 'EUR', symbol: '€', name: 'Euro' },
  { code: 'GBP', symbol: '£', name: 'British Pound' },
  { code: 'INR', symbol: '₹', name: 'Indian Rupee' },
  { code: 'JPY', symbol: '¥', name: 'Japanese Yen' },
  { code: 'AUD', symbol: 'A$', name: 'Australian Dollar' },
  { code: 'CAD', symbol: 'C$', name: 'Canadian Dollar' },
  { code: 'CNY', symbol: '¥', name: 'Chinese Yuan' },
  { code: 'BRL', symbol: 'R$', name: 'Brazilian Real' },
  { code: 'MXN', symbol: '$', name: 'Mexican Peso' },
];

export const DEFAULT_TARIFF_RATE = 0.12; // USD per kWh

// CO2 emission factor (kg CO2 per kWh) - global average
export const CO2_EMISSION_FACTOR = 0.42;

// Average tree CO2 absorption per year (kg)
export const TREE_CO2_ABSORPTION = 21;

// Vehicle emissions (kg CO2 per km)
export const VEHICLE_EMISSIONS_PER_KM = 0.21;

export const CATEGORIES = [
  'Cooling',
  'Kitchen',
  'Laundry',
  'Entertainment',
  'Computing',
  'Heating',
  'Lighting',
  'Electronics',
  'Personal',
  'Other',
];
