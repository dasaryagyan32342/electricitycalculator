export interface Appliance {
  id: string;
  name: string;
  quantity: number;
  powerRating: number; // Watts
  dailyUsageHours: number;
  daysPerMonth: number;
  icon?: string;
  category?: string;
}

export interface AppliancePreset {
  name: string;
  powerRating: number;
  icon: string;
  category: string;
  typicalUsage: number;
}

export interface EnergyCalculations {
  dailyKwh: number;
  monthlyKwh: number;
  yearlyKwh: number;
  dailyCost: number;
  monthlyCost: number;
  yearlyCost: number;
}

export interface CarbonFootprint {
  monthlyCO2Kg: number;
  yearlyCO2Kg: number;
  treesNeeded: number;
  vehicleKmEquivalent: number;
}

export interface Recommendation {
  id: string;
  title: string;
  description: string;
  potentialSavingsKwh: number;
  potentialSavingsPercent: number;
  potentialCostSavings: number;
  priority: 'high' | 'medium' | 'low';
  icon: string;
  appliance?: string;
}

export interface Currency {
  code: string;
  symbol: string;
  name: string;
}

export interface UserSettings {
  tariffRate: number;
  currency: Currency;
  darkMode: boolean;
}
