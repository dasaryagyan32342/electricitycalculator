'use client';

import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { Appliance, UserSettings, Currency } from './types';
import { CURRENCIES, DEFAULT_TARIFF_RATE } from './constants';

interface EnergyContextType {
  appliances: Appliance[];
  addAppliance: (appliance: Omit<Appliance, 'id'>) => void;
  updateAppliance: (id: string, appliance: Partial<Appliance>) => void;
  removeAppliance: (id: string) => void;
  clearAllAppliances: () => void;
  settings: UserSettings;
  updateSettings: (settings: Partial<UserSettings>) => void;
  toggleDarkMode: () => void;
}

const defaultSettings: UserSettings = {
  tariffRate: DEFAULT_TARIFF_RATE,
  currency: CURRENCIES[0],
  darkMode: false,
};

const EnergyContext = createContext<EnergyContextType | undefined>(undefined);

export function EnergyProvider({ children }: { children: React.ReactNode }) {
  const [appliances, setAppliances] = useState<Appliance[]>([]);
  const [settings, setSettings] = useState<UserSettings>(defaultSettings);
  const [isLoaded, setIsLoaded] = useState(false);

  // Load from localStorage on mount
  useEffect(() => {
    const savedAppliances = localStorage.getItem('ecowatt-appliances');
    const savedSettings = localStorage.getItem('ecowatt-settings');
    
    if (savedAppliances) {
      try {
        setAppliances(JSON.parse(savedAppliances));
      } catch (e) {
        console.error('Failed to parse appliances:', e);
      }
    }
    
    if (savedSettings) {
      try {
        setSettings(JSON.parse(savedSettings));
      } catch (e) {
        console.error('Failed to parse settings:', e);
      }
    }
    
    setIsLoaded(true);
  }, []);

  // Save to localStorage when appliances change
  useEffect(() => {
    if (isLoaded) {
      localStorage.setItem('ecowatt-appliances', JSON.stringify(appliances));
    }
  }, [appliances, isLoaded]);

  // Save to localStorage when settings change
  useEffect(() => {
    if (isLoaded) {
      localStorage.setItem('ecowatt-settings', JSON.stringify(settings));
    }
  }, [settings, isLoaded]);

  // Apply dark mode
  useEffect(() => {
    if (settings.darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [settings.darkMode]);

  const addAppliance = useCallback((appliance: Omit<Appliance, 'id'>) => {
    const newAppliance: Appliance = {
      ...appliance,
      id: crypto.randomUUID(),
    };
    setAppliances((prev) => [...prev, newAppliance]);
  }, []);

  const updateAppliance = useCallback((id: string, updates: Partial<Appliance>) => {
    setAppliances((prev) =>
      prev.map((a) => (a.id === id ? { ...a, ...updates } : a))
    );
  }, []);

  const removeAppliance = useCallback((id: string) => {
    setAppliances((prev) => prev.filter((a) => a.id !== id));
  }, []);

  const clearAllAppliances = useCallback(() => {
    setAppliances([]);
  }, []);

  const updateSettings = useCallback((newSettings: Partial<UserSettings>) => {
    setSettings((prev) => ({ ...prev, ...newSettings }));
  }, []);

  const toggleDarkMode = useCallback(() => {
    setSettings((prev) => ({ ...prev, darkMode: !prev.darkMode }));
  }, []);

  return (
    <EnergyContext.Provider
      value={{
        appliances,
        addAppliance,
        updateAppliance,
        removeAppliance,
        clearAllAppliances,
        settings,
        updateSettings,
        toggleDarkMode,
      }}
    >
      {children}
    </EnergyContext.Provider>
  );
}

export function useEnergy() {
  const context = useContext(EnergyContext);
  if (context === undefined) {
    throw new Error('useEnergy must be used within an EnergyProvider');
  }
  return context;
}
