import { Appliance, EnergyCalculations, CarbonFootprint, Recommendation } from './types';
import { CO2_EMISSION_FACTOR, TREE_CO2_ABSORPTION, VEHICLE_EMISSIONS_PER_KM } from './constants';

export function calculateApplianceEnergy(appliance: Appliance): {
  dailyKwh: number;
  monthlyKwh: number;
  yearlyKwh: number;
} {
  const dailyKwh = (appliance.powerRating * appliance.dailyUsageHours * appliance.quantity) / 1000;
  const monthlyKwh = dailyKwh * appliance.daysPerMonth;
  const yearlyKwh = monthlyKwh * 12;
  
  return { dailyKwh, monthlyKwh, yearlyKwh };
}

export function calculateTotalEnergy(appliances: Appliance[], tariffRate: number): EnergyCalculations {
  let dailyKwh = 0;
  let monthlyKwh = 0;
  let yearlyKwh = 0;

  appliances.forEach((appliance) => {
    const energy = calculateApplianceEnergy(appliance);
    dailyKwh += energy.dailyKwh;
    monthlyKwh += energy.monthlyKwh;
    yearlyKwh += energy.yearlyKwh;
  });

  return {
    dailyKwh,
    monthlyKwh,
    yearlyKwh,
    dailyCost: dailyKwh * tariffRate,
    monthlyCost: monthlyKwh * tariffRate,
    yearlyCost: yearlyKwh * tariffRate,
  };
}

export function calculateCarbonFootprint(monthlyKwh: number): CarbonFootprint {
  const monthlyCO2Kg = monthlyKwh * CO2_EMISSION_FACTOR;
  const yearlyCO2Kg = monthlyCO2Kg * 12;
  const treesNeeded = Math.ceil(yearlyCO2Kg / TREE_CO2_ABSORPTION);
  const vehicleKmEquivalent = Math.round(yearlyCO2Kg / VEHICLE_EMISSIONS_PER_KM);

  return {
    monthlyCO2Kg,
    yearlyCO2Kg,
    treesNeeded,
    vehicleKmEquivalent,
  };
}

export function generateRecommendations(
  appliances: Appliance[],
  tariffRate: number
): Recommendation[] {
  const recommendations: Recommendation[] = [];

  appliances.forEach((appliance) => {
    const energy = calculateApplianceEnergy(appliance);
    const applianceLower = appliance.name.toLowerCase();

    // AC recommendations
    if (applianceLower.includes('air conditioner') || applianceLower.includes('ac')) {
      if (appliance.dailyUsageHours > 6) {
        const savingsPercent = 15;
        const savingsKwh = energy.monthlyKwh * (savingsPercent / 100);
        recommendations.push({
          id: `ac-temp-${appliance.id}`,
          title: 'Optimize AC Temperature',
          description: 'Set your AC to 24-26°C instead of lower temperatures. Each degree higher can save 3-5% energy.',
          potentialSavingsKwh: savingsKwh,
          potentialSavingsPercent: savingsPercent,
          potentialCostSavings: savingsKwh * tariffRate,
          priority: 'high',
          icon: 'Thermometer',
          appliance: appliance.name,
        });
      }
    }

    // Refrigerator recommendations
    if (applianceLower.includes('refrigerator') || applianceLower.includes('fridge')) {
      const savingsPercent = 10;
      const savingsKwh = energy.monthlyKwh * (savingsPercent / 100);
      recommendations.push({
        id: `fridge-${appliance.id}`,
        title: 'Optimize Refrigerator Settings',
        description: 'Keep your refrigerator at 3-4°C and freezer at -18°C. Ensure door seals are tight and keep it away from heat sources.',
        potentialSavingsKwh: savingsKwh,
        potentialSavingsPercent: savingsPercent,
        potentialCostSavings: savingsKwh * tariffRate,
        priority: 'medium',
        icon: 'Refrigerator',
        appliance: appliance.name,
      });
    }

    // Lighting recommendations (non-LED bulbs)
    if (applianceLower.includes('bulb') && !applianceLower.includes('led')) {
      const savingsPercent = 75;
      const savingsKwh = energy.monthlyKwh * (savingsPercent / 100);
      recommendations.push({
        id: `lighting-${appliance.id}`,
        title: 'Switch to LED Lighting',
        description: 'Replace incandescent or CFL bulbs with LED bulbs. LEDs use up to 75% less energy and last 25 times longer.',
        potentialSavingsKwh: savingsKwh,
        potentialSavingsPercent: savingsPercent,
        potentialCostSavings: savingsKwh * tariffRate,
        priority: 'high',
        icon: 'Lightbulb',
        appliance: appliance.name,
      });
    }

    // Computer standby
    if (applianceLower.includes('computer') || applianceLower.includes('desktop')) {
      const savingsPercent = 20;
      const savingsKwh = energy.monthlyKwh * (savingsPercent / 100);
      recommendations.push({
        id: `computer-${appliance.id}`,
        title: 'Enable Power Management',
        description: 'Use sleep mode and power management settings. Turn off computer when not in use instead of leaving it on standby.',
        potentialSavingsKwh: savingsKwh,
        potentialSavingsPercent: savingsPercent,
        potentialCostSavings: savingsKwh * tariffRate,
        priority: 'medium',
        icon: 'Monitor',
        appliance: appliance.name,
      });
    }

    // Water heater
    if (applianceLower.includes('water heater') || applianceLower.includes('geyser')) {
      if (appliance.dailyUsageHours > 2) {
        const savingsPercent = 30;
        const savingsKwh = energy.monthlyKwh * (savingsPercent / 100);
        recommendations.push({
          id: `heater-${appliance.id}`,
          title: 'Optimize Water Heater Usage',
          description: 'Use a timer for your water heater. Reduce temperature to 50°C and insulate the tank to retain heat longer.',
          potentialSavingsKwh: savingsKwh,
          potentialSavingsPercent: savingsPercent,
          potentialCostSavings: savingsKwh * tariffRate,
          priority: 'high',
          icon: 'Flame',
          appliance: appliance.name,
        });
      }
    }

    // TV recommendations
    if (applianceLower.includes('television') || applianceLower.includes('tv')) {
      if (appliance.dailyUsageHours > 4) {
        const savingsPercent = 15;
        const savingsKwh = energy.monthlyKwh * (savingsPercent / 100);
        recommendations.push({
          id: `tv-${appliance.id}`,
          title: 'Reduce TV Standby Power',
          description: 'Use a smart power strip to completely cut power when TV is off. Reduce brightness and use energy-saving mode.',
          potentialSavingsKwh: savingsKwh,
          potentialSavingsPercent: savingsPercent,
          potentialCostSavings: savingsKwh * tariffRate,
          priority: 'low',
          icon: 'Tv',
          appliance: appliance.name,
        });
      }
    }
  });

  // General recommendations if appliances exist
  if (appliances.length > 0) {
    const totalEnergy = calculateTotalEnergy(appliances, tariffRate);
    
    recommendations.push({
      id: 'smart-strips',
      title: 'Use Smart Power Strips',
      description: 'Smart power strips can eliminate phantom loads from devices on standby, saving up to 10% on electricity.',
      potentialSavingsKwh: totalEnergy.monthlyKwh * 0.05,
      potentialSavingsPercent: 5,
      potentialCostSavings: totalEnergy.monthlyCost * 0.05,
      priority: 'medium',
      icon: 'Plug',
    });

    recommendations.push({
      id: 'off-peak',
      title: 'Schedule Heavy Appliances Off-Peak',
      description: 'Run washing machines, dishwashers, and other heavy appliances during off-peak hours to save on time-of-use rates.',
      potentialSavingsKwh: totalEnergy.monthlyKwh * 0.08,
      potentialSavingsPercent: 8,
      potentialCostSavings: totalEnergy.monthlyCost * 0.08,
      priority: 'medium',
      icon: 'Clock',
    });

    recommendations.push({
      id: 'insulation',
      title: 'Improve Home Insulation',
      description: 'Proper insulation can reduce heating and cooling costs by 15-20%. Check windows, doors, and attic insulation.',
      potentialSavingsKwh: totalEnergy.monthlyKwh * 0.12,
      potentialSavingsPercent: 12,
      potentialCostSavings: totalEnergy.monthlyCost * 0.12,
      priority: 'high',
      icon: 'Home',
    });
  }

  // Sort by potential savings
  return recommendations.sort((a, b) => b.potentialCostSavings - a.potentialCostSavings);
}

export function calculateEfficiencyScore(appliances: Appliance[]): number {
  if (appliances.length === 0) return 100;

  let score = 100;
  let deductions = 0;

  appliances.forEach((appliance) => {
    const applianceLower = appliance.name.toLowerCase();
    
    // High usage deductions
    if (appliance.dailyUsageHours > 8) {
      deductions += 5;
    }
    
    // High power appliances running long
    if (appliance.powerRating > 1000 && appliance.dailyUsageHours > 4) {
      deductions += 8;
    }
    
    // Non-LED lighting
    if (applianceLower.includes('bulb') && !applianceLower.includes('led')) {
      deductions += 10;
    }
    
    // AC running too long
    if ((applianceLower.includes('air conditioner') || applianceLower.includes('ac')) && appliance.dailyUsageHours > 10) {
      deductions += 15;
    }
  });

  score = Math.max(0, score - deductions);
  return Math.round(score);
}

export function formatCurrency(amount: number, symbol: string): string {
  return `${symbol}${amount.toFixed(2)}`;
}

export function formatKwh(kwh: number): string {
  if (kwh >= 1000) {
    return `${(kwh / 1000).toFixed(2)} MWh`;
  }
  return `${kwh.toFixed(2)} kWh`;
}
